# mypackage

This library contains functions that can be used to create packages for PCs

# How to install
... 